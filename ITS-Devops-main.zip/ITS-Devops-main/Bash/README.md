# Bash Scripts

## Table of Contents

- [Batch File Rename](#about)
- [File Rename](#getting_started)
- [Adress Book](#usage)


## Batch File Rename <a name = "about"></a>
For example This will rename all .dat files in the tmp directory to .txt.
```
$ ./batchrename.sh tmp dat txt
```
## File Rename <a name = "getting_started"></a>

To use, make the file executable via chmod +x and run in the desired directory.

At each launch, it will create the next 25 files, automatically selecting the numbering.



## Address Book <a name = "usage"></a>

To run, make the file executable via chmod +x and call with arguments as shown in the example.
